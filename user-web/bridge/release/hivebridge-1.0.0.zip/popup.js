(()=>{var n=t=>document.getElementById(t);function i(t){chrome.storage.local.get("bridgeConfig",s=>{t(s.bridgeConfig||{serverUrl:"http://localhost:8080",token:"",autoConnect:!0})})}function u(t,s){chrome.storage.local.set({bridgeConfig:t},()=>{chrome.runtime.sendMessage({type:"setConfig",config:t},s)})}function r(){chrome.runtime.sendMessage({type:"getStatus"},t=>{if(!t)return n("statusOut").textContent="\u65E0\u54CD\u5E94";let s=Object.entries(t.statuses||{}).map(([e,o])=>{let a=o.online?"status-on":"status-off";return`[${o.online?"\u5728\u7EBF":"\u79BB\u7EBF"}] ${e} \u4F1A\u8BDD:${o.conversationId||"-"} \u8D26\u53F7:${o.accountId||"-"}`});n("statusOut").innerHTML=s.length?s.map(e=>`<span class="${e.includes("\u5728\u7EBF")?"status-on":"status-off"}">${e}</span>`).join(`
`):"\u5F53\u524D\u65E0\u5DF2\u8FDE\u63A5\u8D26\u53F7"})}function l(){chrome.tabs.query({active:!0,currentWindow:!0},t=>{let s=t[0];if(!s)return n("selfOut").textContent="\u65E0\u6D3B\u52A8\u6807\u7B7E\u9875";chrome.tabs.sendMessage(s.id,{type:"selfcheck"},e=>{if(chrome.runtime.lastError||!e)return n("selfOut").textContent="\u8BE5\u9875\u9762\u672A\u6CE8\u5165\u6865\u63A5\uFF08\u8BF7\u786E\u8BA4\u5728\u6296\u97F3/\u5C0F\u7EA2\u4E66/TikTok \u79C1\u4FE1\u9875\uFF0C\u4E14\u6269\u5C55\u5DF2\u52A0\u8F7D\uFF09";let o=e.selectors?`
\u9009\u62E9\u5668:
`+JSON.stringify(e.selectors,null,1):"",a=(e.sample||[]).map(c=>`  [${c.sender}] ${c.text}`).join(`
`);n("selfOut").textContent=`\u9891\u9053: ${e.channel}
\u5339\u914D: ${e.matched}
\u8D26\u53F7: ${e.accountId}
\u4F1A\u8BDD: ${e.conversationId}
\u6D88\u606F\u6761\u76EE: ${e.msgItemCount}
\u6837\u672C:
${a}${o}`})})}document.addEventListener("DOMContentLoaded",()=>{i(t=>{n("serverUrl").value=t.serverUrl||"",n("token").value=t.token||""}),n("save").addEventListener("click",()=>{let t={serverUrl:n("serverUrl").value.trim(),token:n("token").value.trim(),autoConnect:!0};u(t,()=>{n("save").textContent="\u5DF2\u4FDD\u5B58",setTimeout(()=>n("save").textContent="\u4FDD\u5B58\u5E76\u8FDE\u63A5",1500),r()})}),n("status").addEventListener("click",r),n("selfcheck").addEventListener("click",l),r()});})();
